package com.example.emma_baumstarck.todoapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.SimpleDateFormat;

public class EditActivity extends AppCompatActivity {
    Toolbar toolbar;

    EditText taskNameText;
    TodoItem todoItem;
    TextView taskCreatedAtView;
    TextView taskUpdatedAtView;

    RadioButton priorityLowRadio;
    RadioButton priorityRegularRadio;
    RadioButton priorityHighRadio;

    public static final String TASK_ID_KEY = "taskId";
    public static final String OPERATION_CODE_KEY = "operationCode";
    public static final int NOOP_CODE = 0;
    public static final int EDITED_CODE = 1;
    public static final int DELETED_CODE = 2;

    public static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        toolbar = (Toolbar) findViewById(R.id.editToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        setTitle("Edit Item");
//        toolbar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_action_back));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        taskNameText = (EditText) findViewById(R.id.taskNameText);
        taskCreatedAtView = (TextView) findViewById(R.id.taskCreatedAtView);
        taskUpdatedAtView = (TextView) findViewById(R.id.taskUpdatedAtView);

        priorityLowRadio = (RadioButton) findViewById(R.id.priorityLowRadio);
        priorityRegularRadio = (RadioButton) findViewById(R.id.priorityRegularRadio);
        priorityHighRadio = (RadioButton) findViewById(R.id.priorityHighRadio);

        long taskId = getIntent().getExtras().getInt(TASK_ID_KEY);
        todoItem = TodoItemsHandler.getInstance().getTodo(taskId);

        taskNameText.setText(todoItem.getValue());
        taskNameText.setSelection(taskNameText.getText().length());

        taskCreatedAtView.setText(
                new SimpleDateFormat(DATE_FORMAT).format(
                        new java.sql.Timestamp(todoItem.getCreatedAtMs())));
        taskUpdatedAtView.setText(
                new SimpleDateFormat(DATE_FORMAT).format(
                        new java.sql.Timestamp(todoItem.getUpdatedAtMs())));

        switch (todoItem.getPriority()) {
            case TodoItemsTableProvider.PRIORITY_LOW:
                priorityLowRadio.setChecked(true);
                break;
            case TodoItemsTableProvider.PRIORITY_REGULAR:
                priorityRegularRadio.setChecked(true);
                break;
            case TodoItemsTableProvider.PRIORITY_HIGH:
                priorityHighRadio.setChecked(true);
                break;
        }
    }

    private Intent setActivityResult(int operationCode) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra(TASK_ID_KEY, todoItem.getId());
        resultIntent.putExtra(OPERATION_CODE_KEY, operationCode);
        setResult(Activity.RESULT_OK, resultIntent);
        return resultIntent;
    }

    public void onCancelButton(View view) {
        finish();
    }

    public void onUpdateButton(View view) {
        int priority;
        if (priorityLowRadio.isChecked()) {
            priority = TodoItemsTableProvider.PRIORITY_LOW;
        } else if (priorityHighRadio.isChecked()) {
            priority = TodoItemsTableProvider.PRIORITY_HIGH;
        } else {
            priority = TodoItemsTableProvider.PRIORITY_REGULAR;
        }

        TodoItemsHandler.getInstance().updateTodo(
                todoItem,
                taskNameText.getText().toString(),
                priority);
        setActivityResult(EDITED_CODE);
        finish();
    }

//    public void onDeleteButton(View view) {
//        new AlertDialog.Builder(this)
//                .setTitle("Delete TODO")
//                .setMessage("Do you really want to delete this item?")
//                .setIcon(android.R.drawable.ic_dialog_alert)
//                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int whichButton) {
//                        TodoItemsHandler.getInstance().deleteTodo(todoItem);
//                        setActivityResult(DELETED_CODE);
//                        finish();
//                    }
//                })
//                .setNegativeButton(android.R.string.no, null).show();
//    }
}
