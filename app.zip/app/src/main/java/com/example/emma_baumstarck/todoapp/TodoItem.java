package com.example.emma_baumstarck.todoapp;

/**
 * Created by emma_baumstarck on 7/11/16.
 */
public class TodoItem {
    private int id;
    private String value;
    private long createdAtMs;
    private long updatedAtMs;
    private int priority;

    public TodoItem(int id, String value, long createdAtMs, long updatedAtMs, int priority) {
        this.id = id;
        this.value = value;
        this.createdAtMs = createdAtMs;
        this.updatedAtMs = updatedAtMs;
        this.priority = priority;
    }

    public int getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public long getCreatedAtMs() {
        return createdAtMs;
    }

    public void setCreatedAtMs(long createdAtMs) {
        this.createdAtMs = createdAtMs;
    }

    public long getUpdatedAtMs() {
        return updatedAtMs;
    }

    public void setUpdatedAtMs(long updatedAtMs) {
        this.updatedAtMs = updatedAtMs;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    @Override
    public String toString() {
        return value;
    }
}
